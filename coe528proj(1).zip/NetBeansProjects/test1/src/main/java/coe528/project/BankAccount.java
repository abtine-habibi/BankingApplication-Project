package coe528.project;

import java.util.*;

// Overview: BankAccount is an abstract class representing a bank account
// The abstraction function is:
// AF(balance) = a bank account with a balance representing the amount of money in the account
//
// The rep invariant is:
// balance >= 0
public abstract class BankAccount {
    public double balance; 
    
    //constructor
    public BankAccount(){
        // EFFECTS: Initializes the instance variable balance to 100
        balance = 100; 
    }
    
    // Setter for balance
    protected void setBalance(double newBalance){
        // MODIFIES: Balance 
        // EFFECTS: Sets the balance to a new balance value if the new balance is non-negative
        if (newBalance >= 0){
            this.balance = newBalance; 
        }
    }
    
    
    protected void addMoney(double amount){
        // REQUIRES: A double amount input that is greater or equal to 0
        // MODIFIES: The balance
        // EFFECTS: Increases the balance by amount if the amount is non-negative
        if (amount >= 0){
            this.balance += amount;
        }
    }
    
   
    protected void removeMoney(double amount){
        // REQUIRES: A double amount input that is greater or equal to 0
        // MODIFIES: The balance
        // EFFECTS: Decreases the balance by amount if the amount is non-negative
        if (amount >= 0){
            this.balance -= amount;
        }
    }
    
    
    public void onlinePurchase(double amount){
        // This method is abstract and will be implemented in subclasses
    }
    
    
    public String getAccountLevel(){
        // This method is abstract and will be implemented in subclasses
        return "String in Abstract";
    }
    
    
    @Override
    public String toString(){
        // EFFECTS: Returns a string representation of the balance
        return "Balance is $" + this.balance;
    }
    
    
    public boolean repOK(){
        //EFFECTS: returns true if the balance is greater than or equal to 0, otherwise returns false
        //Rep invariant: the balance must be greater than or equal to 0
        return this.balance >= 0;
    }
}
