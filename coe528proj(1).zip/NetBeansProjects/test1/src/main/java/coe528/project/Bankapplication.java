package coe528.project;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.control.Label;
import java.util.*;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import static javafx.application.Application.launch;
import javafx.scene.control.PasswordField;

public class Bankapplication extends Application {
   

    private Button loginButton;
    private Scene loginPage, managerPage, customerPage;
    private static ArrayList<Customer> customers = new ArrayList<Customer>();
    private static Manager admin = new Manager();
    private Customer tempCustomer;
    private int index = -1;
    
    public static void main(String[] args) {
               
         String currentDirectory = System.getProperty("user.dir"); 
         File dir = new File(currentDirectory);
         for(File file : dir.listFiles()){
             if(file.getName().endsWith((".txt"))){
                    try(Scanner readFile = new Scanner(file)){
                        String un = readFile.next();
                        String pw = readFile.next();
                        double balance = Double.parseDouble(readFile.next());
                        customers.add(new Customer(un,pw));
                        for(Customer c : customers){
                            if(c.getUsername().equals(un))
                                c.deposit(c.getBalance() - 100); 
                                c.setAccountLevel();
                        }
                    }
                    catch(Exception e3){}  
             }
         }
         
        launch(args);
        
    }
    
    @Override
    public void start(Stage window) throws Exception {
        
        window.setTitle("Banking Application");
        
        //Labels for loginPage
        Label label1 = new Label("Username");
        Label label2 = new Label("Password");
        
        //Labels for Manager page
        Label label3 = new Label("Create a new Customer ");
        Label label4 = new Label("New Customer's username:");
        Label label5 = new Label("New Customer's password:");
        Label label6 = new Label("\n\n\n");
        Label label7 = new Label("Which customer would you like to delete?:");
        Label label8 = new Label("\n\n\n");
        
        //Labels for Customer page
        Label depositLabel = new Label("\n\nDeposit Amount:");
        Label withdrawLabel = new Label("\n\nWithdrawl Amount:");
        Label onlinePurchaseLabel = new Label("\n\nOnline Purchase Amount:");
        Label spaces = new Label("\n\n\n");
        
        //Textfields for customer page
        TextField depositMoney = new TextField();
        TextField withdrawMoney = new TextField();
        TextField op = new TextField();
         
        //Buttons for customer page
        Button getBalanceButton = new Button("Account Balance");
        Button getCurrentLevel = new Button("Current Level");
        Button doDepositAction = new Button("Deposit");
        Button doWithdrawAction = new Button("Withdraw");
        Button doOnlinePurchase = new Button("Complete Transaction");
        Button userLogout = new Button("Logout");
        
    
        TextField username = new TextField();
        PasswordField password = new PasswordField();
        loginButton = new Button("Login");
        
        Button createCustomer = new Button("Create Customer");
        Button deleteCustomer = new Button("Delete Customer");
        Button managerLogout = new Button("Logout");
        TextField createUsername = new TextField();
        TextField createPassword = new TextField();
        TextField userToDelete = new TextField();
        
        //Setting all button actions
        loginButton.setOnAction(e ->{ 
               String inputtedFileName = username.getText();
               String inputtedPassword = password.getText();
               File f = new File(inputtedFileName + ".txt");
               if(f.exists()) { 
                    try(Scanner readFile = new Scanner(f)){
                         String usernameOnFile = readFile.next();
                         String passwordOnFile = readFile.next();
                        
                    if(inputtedFileName.equals(usernameOnFile) && inputtedPassword.equals(passwordOnFile)){ 
                        if(usernameOnFile.equals("admin")){
                        AlertBox.display("Success", "Logged In");
                            window.setScene(managerPage);
                            username.clear();
                            password.clear();
                        }
                        
                        
                        else {  //we are also setting our tempCust variable to the 
                           for(int i = 0; i < customers.size(); i++){    
                                  if(customers.get(i).getUsername().equals(inputtedFileName)){
                                      tempCustomer = customers.get(i);
                                      index = i;
                                  }                        
                           }
                           	AlertBox.display("Success", "Logged In");
                                      window.setScene(customerPage);
                                      username.clear();
                                      password.clear();
                          
                        } 
  
                    }
                    else
                        AlertBox.display("Error", "Invalid Login");
                    }  
                    catch(Exception e1){
                         System.out.println("Something went wrong");
                        }            
               } 
               
               else{
                   AlertBox.display("Error", "User does not exist!");
                           
               }
                                           
        });
        
        managerLogout.setOnAction(e -> {
          
            window.setScene(loginPage);
            createUsername.clear();
            createPassword.clear();
            userToDelete.clear();
         
        } );
        
        
        userLogout.setOnAction(e -> { 
                        try{
                FileWriter writeToFile = new FileWriter(tempCustomer.getUsername() + ".txt");
                writeToFile.write(tempCustomer.getUsername() + "\n");
                writeToFile.write(tempCustomer.getPassword() + "\n");
                writeToFile.write(""+tempCustomer.account.balance);
                writeToFile.close();
            }
            catch(Exception w){}
            
            window.setScene(loginPage);
            depositMoney.clear();
            withdrawMoney.clear();
            op.clear(); //online purchase 
                });
        
        createCustomer.setOnAction(e -> {
                customers.add(new Customer(createUsername.getText(),createPassword.getText()));
                createUsername.clear();
                createPassword.clear();
                AlertBox.display("New Customer", "Customer has been created!");
                });
        
        deleteCustomer.setOnAction(e -> {
           String deleteThisUsername = userToDelete.getText();
           for(int i = 0; i < customers.size() ; i++){
               if(customers.get(i).getUsername().equals(deleteThisUsername)){
                   admin.deleteCustomer(customers.get(i));
                   customers.remove(i);
                   userToDelete.clear(); //removing text from field
                   break;
               }
           }          
        });
        
        getBalanceButton.setOnAction(e ->{
            AlertBox.display("Balance", "Balance is $" +tempCustomer.getBalance());
        });
        
        
        getCurrentLevel.setOnAction(e -> {
            AlertBox.display("Balance", tempCustomer.account.getAccountLevel());
        });
       
        doDepositAction.setOnAction(e ->{
            try{
                double amount = Double.parseDouble(depositMoney.getText());
                tempCustomer.deposit(amount);
                depositMoney.clear();
            }
            catch(NumberFormatException e1){
                     AlertBox.display("Error", "A double must be entered!");  
                     depositMoney.clear();
            }      
        });
        
        doWithdrawAction.setOnAction(e -> {
            //textfield is withdraw money
            try{
                double amount = Double.parseDouble(withdrawMoney.getText());
                tempCustomer.withdraw(amount);
                withdrawMoney.clear();
            }
            catch(NumberFormatException e1){
                     AlertBox.display("Error", "A double must be entered!");  
                     withdrawMoney.clear();
            }      
        });
        
        doOnlinePurchase.setOnAction(e -> {
             try{
                double amount = Double.parseDouble(op.getText());
                tempCustomer.onlinePurchase(amount);
                op.clear();
            }
            catch(NumberFormatException e1){
                     AlertBox.display("Error", "A double must be entered!");
                     op.clear();
            }  
        });
        
                    
        //Layout of login page
        VBox layout1 = new VBox(10);
        layout1.setPadding(new Insets(20,20,20,20));
        layout1.getChildren().addAll(label1,username,label2,password,loginButton);
        
        loginPage = new Scene(layout1,200,200);
       
        //Layout of Manager page   
        VBox layout2 = new VBox(10);
        layout2.setPadding(new Insets(20,20,20,20));
        layout2.getChildren().addAll(label3,label4,createUsername,label5,createPassword,createCustomer,label6,label7,userToDelete,deleteCustomer,label8,managerLogout);
        
        managerPage = new Scene(layout2,500,500);
        
        //Layout of Customer page
        VBox layout3 = new VBox(10);
        layout3.setPadding(new Insets(20,20,20,20));
        layout3.getChildren().addAll(getBalanceButton,getCurrentLevel,depositLabel,depositMoney,doDepositAction,withdrawLabel,withdrawMoney,doWithdrawAction,onlinePurchaseLabel,op,doOnlinePurchase,spaces,userLogout);
        
        customerPage = new Scene(layout3,500,500);
        
        window.setScene(loginPage);
        window.show();
       
        
    }
}
