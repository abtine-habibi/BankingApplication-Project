
package coe528.project;

import java.io.File;
import java.io.IOException;
import java.io.FileWriter;
import java.util.*;

public class Customer extends User{
  
    public BankAccount account; 
    
    public Customer(String username, String password) {
        super(username, password, "customer");
        try {
            File loginInfo = new File(username + ".txt");
            if (loginInfo.createNewFile()) {
                System.out.println("User created:" + loginInfo.getName());
                account = new SilverLevel(); // Initialize account
                FileWriter writeToFile = new FileWriter(username + ".txt");
                writeToFile.write(username + "\n");
                writeToFile.write(password + "\n");
                writeToFile.write("" + 100); // Initial balance
                writeToFile.close();
                this.setAccountLevel();
            } else if (loginInfo.exists()) {
                // User already exists, load data from file
                Scanner scanner = new Scanner(loginInfo);
                this.username = scanner.nextLine();
                this.password = scanner.nextLine();
                account.balance = Double.parseDouble(scanner.nextLine());
                this.setAccountLevel();
                scanner.close();
            } else {
                AlertBox.display("ERROR","Customer Already Exists");
                return;
            }
        } catch (IOException e) {
            System.out.println("IOException occurred");
        }
    }
        
    
    public void deposit(double amount){
    	if(amount >= 0) {
        account.addMoney(amount);
        AlertBox.display("Success!", "Deposit $" + amount + " has been deposited");
        this.setAccountLevel();
    	}
    	else {AlertBox.display("ERROR", "Amount entered must be a positive value");}

    }
    
    public void withdraw (double amount){
        if (account.balance >= amount){
            account.removeMoney(amount);
            AlertBox.display("Success!", "Withdraw of $" + amount + " has been withdrawn");
            this.setAccountLevel();
    
        }
        else {
            AlertBox.display("ERROR", "Insufficient funds for withdrawl");
        }
    }
    
    public void onlinePurchase(double amount){
        if(amount < 50){
            AlertBox.display("ERROR", "Online purchases must have a minimum amount of $50.00");
        }
        account.onlinePurchase(amount);
        this.setAccountLevel();

    }
    
    public void setAccountLevel(){
        double balance = this.getBalance();

        if(balance < 10000){
            account = new SilverLevel();
            account.setBalance(balance);
        }
        if(balance >= 10000 && balance < 20000){
            account = new GoldLevel();
            account.setBalance(balance);
        }       
        if(balance > 20000){
            account = new PlatinumLevel();
            account.setBalance(balance);
        }
    }
    public double getBalance(){
        return account.balance;
    }
    public String getAccountLevel(){
        return account.getAccountLevel();
    }
    public String getUsername(){
        return username;
    }
    public String getPassword(){
        return password;
    }
}
