/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package coe528.project;

/**
 *
 * @author abtin
 */
public class GoldLevel extends BankAccount {
    
    public void onlinePurchase(double amount){
      if(amount >= 50){
        if (balance >= amount + 10){
            balance -= (amount +10);
        }
        else{
            AlertBox.display("ERROR", "You do not have sufficient funds to purchase amount $" + amount +"with the additional service charge of $10");
        }
      }
    }
    
    public String getAccountLevel(){
        return "You are a Gold Level User";
    }
}
