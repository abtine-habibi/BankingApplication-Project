package coe528.project;

import java.util.*;
import java.io.File;
import java.io.IOException;
import java.io.FileWriter;

public class Manager extends User {
    // Private static instance variable to hold the single instance of Manager
    public static Manager instance;
   

    // Private constructor to prevent external instantiation
    public Manager() {
        super("admin", "admin", "manager");
        try{
            File loginInfo = new File(username + ".txt");
            if(loginInfo.createNewFile() == true){
                FileWriter writeToFile = new FileWriter(username + ".txt");
                writeToFile.write(username + "\n");
                writeToFile.write(password);
                writeToFile.close();
            }
        }catch(IOException e){
            System.out.println("IOException occured");
        }
    }

    // Public static method to retrieve the single instance of Manager
    public static Manager getInstance() {
        // Lazy initialization: create the instance upon first access
        if (instance == null) {
            instance = new Manager();
        }
        return instance;
    }

    // Method to add a customer
    public Customer addCustomer(String username, String password) {
        return new Customer(username, password);
    }
    
    public void deleteCustomer(Customer c){
        File file = new File(c.getUsername() + ".txt");
        if (file.delete()){
            AlertBox.display("Confirmation", "File successfully deleted");
        }
    }
}
