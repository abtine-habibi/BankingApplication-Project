/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package coe528.project;

/**
 *
 * @author abtin
 */
public class PlatinumLevel extends BankAccount {
    
    public void onlinePurchase(double amount){
       if(amount >= 50){
        if (balance >= amount){
            balance -= (amount);
        }
        else{
            AlertBox.display("ERROR", "You do not have sufficient funds to purchase amount $" + amount);
        }
       }
    }
    
    public String getAccountLevel(){
        return "You are a Platinum Level User";
    }
}
