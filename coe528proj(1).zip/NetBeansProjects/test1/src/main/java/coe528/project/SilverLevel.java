/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package coe528.project;

/**
 *
 * @author abtin
 */
public class SilverLevel extends BankAccount {
    
    public void onlinePurchase(double amount){
       if(amount >= 50){
        if (balance >= amount + 20){
            balance -= (amount +20);
        }
        else{
            AlertBox.display("ERROR", "You do not have sufficient funds to purchase amount $" + amount +"with the additional service charge of $20");
        }
       }
    }
    
    public String getAccountLevel(){
        return "You are a Silver Level User";
    }
}
