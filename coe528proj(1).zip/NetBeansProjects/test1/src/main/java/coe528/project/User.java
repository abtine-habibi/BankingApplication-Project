
package coe528.project;

abstract class User {
    protected String username;
    protected String password; 
    protected String role; 
    public User(String n, String p, String r){
        this.username = n;
        this.password = p; 
        this.role = r;
    }
    
}
